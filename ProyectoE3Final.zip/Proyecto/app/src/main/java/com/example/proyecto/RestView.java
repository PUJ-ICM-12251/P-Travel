package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebView;



public class RestView extends AppCompatActivity {

    private WebView elWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rest_view);
        viu();
    }
    private void viu(){

        elWeb=(WebView) findViewById(R.id.webiu);
        elWeb.setWebViewClient(new WebViewClient());
        elWeb.loadUrl("https://lostraveleros.com/curiosidades-de-nueva-york//");
        WebSettings webSettings=elWeb.getSettings();
        webSettings.setJavaScriptEnabled(true);

    }

}
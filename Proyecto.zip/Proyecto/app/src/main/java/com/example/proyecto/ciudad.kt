package com.example.proyecto

import android.graphics.drawable.Drawable

data class ciudad(val nombre:String,val  foto:Int,val descripcion:String,val puntuacion:String)

